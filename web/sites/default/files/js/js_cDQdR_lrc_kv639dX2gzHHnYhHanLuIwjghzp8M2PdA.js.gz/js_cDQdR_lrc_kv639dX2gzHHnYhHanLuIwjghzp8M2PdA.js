(function (Drupal) {
  const message = 'This is a custom message';

  console.log('Console.Print:', message);
})(Drupal);
;
